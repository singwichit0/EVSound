package com.singto.evsound

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.*
import kotlin.math.*

class EvSoundService : Service(), LocationListener {
    companion object {
        const val ACTION_START = "com.singto.evsound.START"
        const val ACTION_SETTINGS = "com.singto.evsound.SETTINGS"
        private const val CHANNEL_ID = "evsound_running"
        private const val NOTIFICATION_ID = 701
    }

    private lateinit var locationManager: LocationManager
    private var audioTrack: AudioTrack? = null
    private var audioThread: Thread? = null
    @Volatile private var running = false
    @Volatile private var speedKmh = 0f
    @Volatile private var intensity = 0.65f
    @Volatile private var soundMode = 0
    private val prefs by lazy { getSharedPreferences("evsound", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        createNotificationChannel()
        loadSettings()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START || !running) startSystem()
        return START_STICKY
    }

    private fun startSystem() {
        if (running) return
        loadSettings()
        startForeground(NOTIFICATION_ID, notification("รอข้อมูล GPS"))
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        running = true
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 250L, 0.5f, this, Looper.getMainLooper())
            } else {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000L, 1f, this, Looper.getMainLooper())
            }
        } catch (_: Exception) { /* Permission/provider can change while running. */ }
        startSynth()
    }

    private fun loadSettings() {
        soundMode = prefs.getInt("sound", 0)
        intensity = (prefs.getInt("intensity", 65) / 100f).coerceIn(0f, 1f)
    }

    override fun onLocationChanged(location: Location) {
        // Ignore inaccurate GPS fixes to reduce sudden sound jumps.
        if (location.hasAccuracy() && location.accuracy > 35f) return
        speedKmh = if (location.hasSpeed()) (location.speed * 3.6f).coerceIn(0f, 80f) else 0f
    }

    private fun startSynth() {
        if (audioThread?.isAlive == true) return
        val sampleRate = 22050
        val minBuffer = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuffer <= 0) return
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(max(minBuffer, 4096))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        running = true
        audioTrack?.play()
        audioThread = Thread {
            val chunk = ShortArray(512)
            var phase = 0.0
            var phase2 = 0.0
            while (running && !Thread.currentThread().isInterrupted) {
                val speed = speedKmh
                // Keep a low idle tone and smoothly raise pitch with speed.
                val baseHz = when (soundMode) {
                    1 -> 95.0 + speed * 5.2
                    2 -> 70.0 + speed * 3.0
                    else -> 65.0 + speed * 4.0
                }
                val volume = (0.05 + (speed / 80.0) * 0.18) * intensity
                for (i in chunk.indices) {
                    val f = baseHz.coerceIn(45.0, 520.0)
                    phase += 2.0 * Math.PI * f / sampleRate
                    phase2 += 2.0 * Math.PI * (f * 1.51) / sampleRate
                    val pulse = if (soundMode == 1) 0.65 + 0.35 * sin(phase * 0.22) else 1.0
                    val sample = (sin(phase) * 0.72 + sin(phase2) * 0.28) * volume * pulse
                    chunk[i] = (sample.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
                }
                audioTrack?.write(chunk, 0, chunk.size)
                if (speed < 1f) Thread.sleep(40)
            }
        }.apply { name = "EVSoundSynth"; priority = Thread.NORM_PRIORITY; start() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "EV Sound running", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val openApp = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("EV Sound").setContentText(message)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openApp).setOngoing(true).build()
    }

    override fun onDestroy() {
        running = false
        try { locationManager.removeUpdates(this) } catch (_: Exception) {}
        audioThread?.interrupt()
        try { audioTrack?.pause(); audioTrack?.flush(); audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android API")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    override fun onBind(intent: Intent?): IBinder? = null
}
