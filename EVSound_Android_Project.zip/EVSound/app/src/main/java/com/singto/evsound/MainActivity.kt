package com.singto.evsound

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import android.view.Gravity
import android.graphics.Color
import android.content.Context

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("evsound", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var speedLabel: TextView
    private lateinit var intensity: SeekBar
    private lateinit var sound: Spinner
    private lateinit var autoStart: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestNeededPermissions()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(Color.rgb(13, 20, 34))
        }
        scroll.addView(panel)

        panel.addView(TextView(this).apply {
            text = "EV SOUND"
            textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        panel.addView(TextView(this).apply {
            text = "SYNTHETIC ELECTRIC VEHICLE AUDIO"
            textSize = 11f; setTextColor(Color.rgb(80, 220, 210)); gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            text = "สถานะ: หยุดทำงาน"
            textSize = 16f; setTextColor(Color.WHITE); setPadding(0, 24, 0, 16)
        }
        panel.addView(status)

        panel.addView(label("รูปแบบเสียง"))
        sound = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("EV Synth", "Space Pulse", "Soft Electric"))
            setSelection(prefs.getInt("sound", 0))
        }
        panel.addView(sound)

        panel.addView(label("ความไวต่อความเร็ว GPS"))
        intensity = SeekBar(this).apply {
            max = 100; progress = prefs.getInt("intensity", 65)
        }
        panel.addView(intensity)
        speedLabel = label("ระดับการตอบสนอง: ${intensity.progress}%")
        panel.addView(speedLabel)
        intensity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                speedLabel.text = "ระดับการตอบสนอง: $p%"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { saveSettings() }
        })

        autoStart = Switch(this).apply {
            text = "เปิดใช้การปรับเสียงตาม GPS"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("gps", true)
            setPadding(0, 12, 0, 12)
        }
        panel.addView(autoStart)

        val start = Button(this).apply { text = "เริ่มระบบเสียง" }
        val stop = Button(this).apply { text = "หยุดระบบเสียง" }
        panel.addView(start); panel.addView(stop)
        start.setOnClickListener {
            saveSettings()
            if (!hasLocationPermission()) {
                requestNeededPermissions()
                status.text = "สถานะ: อนุญาตตำแหน่ง GPS ก่อนเริ่ม"
                return@setOnClickListener
            }
            val i = Intent(this, EvSoundService::class.java).apply { action = EvSoundService.ACTION_START }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            status.text = "สถานะ: กำลังทำงาน (GPS + เสียงสังเคราะห์)"
        }
        stop.setOnClickListener {
            stopService(Intent(this, EvSoundService::class.java))
            status.text = "สถานะ: หยุดทำงาน"
        }
        panel.addView(TextView(this).apply {
            text = "หมายเหตุ: รุ่นเริ่มต้นนี้สร้างเสียงสังเคราะห์ในแอปและส่งไปยังเอาต์พุตเสียงที่ Android เลือก เช่น ลำโพงมือถือหรือ Bluetooth"
            setTextColor(Color.LTGRAY); textSize = 13f; setPadding(0, 22, 0, 0)
        })
        setContentView(scroll)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 15f; setTextColor(Color.WHITE); setPadding(0, 12, 0, 4)
    }

    private fun saveSettings() {
        prefs.edit().putInt("sound", sound.selectedItemPosition)
            .putInt("intensity", intensity.progress)
            .putBoolean("gps", autoStart.isChecked).apply()
        sendBroadcast(Intent(EvSoundService.ACTION_SETTINGS).setPackage(packageName))
    }

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestNeededPermissions() {
        val wanted = mutableListOf<String>()
        if (!hasLocationPermission()) {
            wanted.add(Manifest.permission.ACCESS_FINE_LOCATION)
            wanted.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            wanted.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (wanted.isNotEmpty()) requestPermissions(wanted.toTypedArray(), 41)
    }
}
